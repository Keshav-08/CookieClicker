package com.example.pokemonclicker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.concurrent.atomic.AtomicInteger;

public class KeshavRanganathan extends AppCompatActivity {
    ImageView pokeClicker, ashClicker, professorOakClicker;
    TextView scoreTitle, ashKetchum, professorOak;
    ConstraintLayout constraintLayout;
    LinearLayout linearLayout1, linearLayout2;
    AtomicInteger score;
    Button refundButton;
    boolean refunded;
    boolean scoreGreaterThanZero = false;
    int normScore = 1;
    int ashScore = 1;
    int proffessorScore = 1;
    int refundClicker = 0;
    boolean ashHasClicked = false;
    boolean professorHasClicker = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pokeClicker = findViewById(R.id.pokeClicker);
        ashClicker = findViewById(R.id.ashClicker);
        professorOakClicker = findViewById(R.id.proffesorOakClicker);
        scoreTitle = findViewById(R.id.scoreTitle);
        ashKetchum = findViewById(R.id.ashKetchum);
        professorOak = findViewById(R.id.professorOak);
        constraintLayout = findViewById(R.id.constraintLayout);
        linearLayout1 = findViewById(R.id.linearLayout1);
        linearLayout2 = findViewById(R.id.linearLayout2);
        pokeClicker.setImageResource(R.drawable.pokeclicker);
        ashClicker.setImageResource(R.drawable.ash);
        ashClicker.setVisibility(View.INVISIBLE);
        ashKetchum.setVisibility(View.INVISIBLE);
        professorOak.setVisibility(View.INVISIBLE);
        professorOakClicker.setVisibility(View.INVISIBLE);
        professorOakClicker.setImageResource(R.drawable.oak);
        refundButton = findViewById(R.id.refundButton);
        refundButton.setVisibility(View.INVISIBLE);


        score = new AtomicInteger(0);
        pokeClicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                scoreGreaterThanZero = true;
                RotateAnimation rotateAnimation = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);
                rotateAnimation.setDuration(500);
                view.startAnimation(rotateAnimation);
                int beingAdded = (refundClicker + 1) * normScore;
                if (!refunded)
                    score.getAndAdd(1);
                else
                    score.getAndAdd(beingAdded);
                TextView added = new TextView(KeshavRanganathan.this);
                added.setId(View.generateViewId());
                added.setTypeface(null, Typeface.BOLD);
                added.setTextSize(20);
                if (!refunded)
                    added.setText("+1");
                else
                    added.setText("+" + beingAdded);
                ConstraintLayout.LayoutParams lp = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                added.setLayoutParams(lp);
                constraintLayout.addView(added);
                ConstraintSet cs = new ConstraintSet();
                cs.clone(constraintLayout);
                cs.connect(added.getId(), ConstraintSet.TOP, view.getId(), ConstraintSet.TOP);
                cs.connect(added.getId(), ConstraintSet.LEFT, view.getId(), ConstraintSet.LEFT);
                cs.connect(added.getId(), ConstraintSet.RIGHT, view.getId(), ConstraintSet.RIGHT);
                cs.connect(added.getId(), ConstraintSet.BOTTOM, view.getId(), ConstraintSet.BOTTOM);
                float rand = (float) Math.random();
                cs.setHorizontalBias(added.getId(), rand);
                cs.setVerticalBias(added.getId(), rand);
                cs.applyTo(constraintLayout);
                final TranslateAnimation translateAnimation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, added.getX(), Animation.RELATIVE_TO_SELF, added.getX(), Animation.RELATIVE_TO_SELF, added.getY(), Animation.RELATIVE_TO_SELF, -100f);
                translateAnimation.setDuration(2000);
                added.startAnimation(translateAnimation);
                added.setVisibility(View.INVISIBLE);
                scoreTitle.setText("Pokemon Caught: " + score.get());
                checkForAsh();
                checkForProfessor();
                if (score.get() > ((refundClicker + 1) * 25)) {
                    refundButton.setVisibility(View.VISIBLE);
                    refundButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int temp = 0 - score.get();
                            score.getAndAdd(temp);
                            refunded = true;
                            refundClicker++;
                            scoreTitle.setText("Pokemon Caught: " + score.get());
                            refundButton.setVisibility(View.INVISIBLE);

                        }
                    });
                }

            }
        });
    }

    public void checkForAsh() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (score.get() > ((refundClicker + 1) * 25)) {
                    refundButton.setVisibility(View.VISIBLE);

                    refundButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int temp = 0 - score.get();
                            score.getAndAdd(temp);
                            refunded = true;
                            refundClicker++;
                            scoreTitle.setText("Pokemon Caught: " + score.get());
                            refundButton.setVisibility(View.INVISIBLE);

                        }
                    });
                }

                if (score.get() >= 5) {

                    ashClicker.setVisibility(View.VISIBLE);
                    AlphaAnimation alphaAnimation = new AlphaAnimation(0, .5f);
                    alphaAnimation.setDuration(750);
                    if (!ashHasClicked) {
                        ashClicker.startAnimation(alphaAnimation);
                        ashHasClicked = true;
                    }
                    ashKetchum.setVisibility(View.VISIBLE);
                    ashClicker.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ashHasClicked = false;
                            new ashThread().start();
                            score.getAndAdd(-5);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    scoreTitle.setText("Pokemon Caught: " + score.get());
                                }
                            });
                            if (score.get() < 10) {
                                professorOak.setVisibility(View.INVISIBLE);
                                professorOakClicker.setVisibility(View.INVISIBLE);
                            }
                            AlphaAnimation alphaAnimation2 = new AlphaAnimation(.5f, 0);
                            alphaAnimation2.setDuration(750);
                            ashClicker.startAnimation(alphaAnimation2);
                            ashClicker.setVisibility(View.INVISIBLE);
                            ashKetchum.setVisibility(View.INVISIBLE);
                            ImageView ashAdd = new ImageView(KeshavRanganathan.this);
                            ashAdd.setId(View.generateViewId());
                            ashAdd.setImageResource(R.drawable.ash);
                            ConstraintLayout.LayoutParams lp = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                            ashAdd.setLayoutParams(lp);
                            ashAdd.getLayoutParams().width = 200;
                            ashAdd.requestLayout();
                            ashAdd.getLayoutParams().height = 200;
                            ashAdd.requestLayout();
                            linearLayout1.addView(ashAdd);
                            ConstraintSet cs = new ConstraintSet();
                            cs.clone(constraintLayout);
                            cs.connect(ashAdd.getId(), ConstraintSet.TOP, linearLayout1.getId(), ConstraintSet.TOP);
                            cs.connect(ashAdd.getId(), ConstraintSet.LEFT, linearLayout1.getId(), ConstraintSet.LEFT);
                            cs.connect(ashAdd.getId(), ConstraintSet.RIGHT, linearLayout1.getId(), ConstraintSet.RIGHT);
                            cs.connect(ashAdd.getId(), ConstraintSet.BOTTOM, linearLayout1.getId(), ConstraintSet.BOTTOM);
                            cs.applyTo(constraintLayout);

                        }
                    });
                }
            }
        });
    }

    public void checkForProfessor() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (score.get() > ((refundClicker + 1) * 25)) {
                    refundButton.setVisibility(View.VISIBLE);
                    refundButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int temp = 0 - score.get();
                            score.getAndAdd(temp);
                            refunded = true;
                            refundClicker++;
                            scoreTitle.setText("Pokemon Caught: " + score.get());
                            refundButton.setVisibility(View.INVISIBLE);

                        }
                    });
                }
                if (score.get() >= 10) {

                    professorOak.setVisibility(View.VISIBLE);
                    AlphaAnimation alphaAnimation = new AlphaAnimation(0, .5f);
                    alphaAnimation.setDuration(750);
                    if (!professorHasClicker) {
                        professorOakClicker.startAnimation(alphaAnimation);
                        professorHasClicker = true;
                    }
                    professorOakClicker.setVisibility(View.VISIBLE);
                    professorOakClicker.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            new professorOakThread().start();
                            professorHasClicker = false;
                            score.getAndAdd(-10);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    scoreTitle.setText("Pokemon Caught: " + score.get());
                                }
                            });
                            AlphaAnimation alphaAnimation2 = new AlphaAnimation(.5f, 0);
                            alphaAnimation2.setDuration(750);
                            if (score.get() < 5) {
                                ashClicker.setVisibility(View.INVISIBLE);
                                ashKetchum.setVisibility((View.INVISIBLE));
                            }
                            professorOakClicker.startAnimation(alphaAnimation2);
                            professorOakClicker.setVisibility(View.INVISIBLE);
                            professorOak.setVisibility(View.INVISIBLE);
                            ImageView professorOakAdd = new ImageView(KeshavRanganathan.this);
                            professorOakAdd.setId(View.generateViewId());
                            professorOakAdd.setImageResource(R.drawable.oak);
                            ConstraintLayout.LayoutParams lp = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                            professorOakAdd.setLayoutParams(lp);
                            professorOakAdd.getLayoutParams().width = 200;
                            professorOakAdd.requestLayout();
                            professorOakAdd.getLayoutParams().height = 200;
                            professorOakAdd.requestLayout();
                            linearLayout2.addView(professorOakAdd);
                            ConstraintSet cs = new ConstraintSet();
                            cs.clone(constraintLayout);
                            cs.connect(professorOakAdd.getId(), ConstraintSet.TOP, linearLayout2.getId(), ConstraintSet.TOP);
                            cs.connect(professorOakAdd.getId(), ConstraintSet.LEFT, linearLayout2.getId(), ConstraintSet.LEFT);
                            cs.connect(professorOakAdd.getId(), ConstraintSet.RIGHT, linearLayout2.getId(), ConstraintSet.RIGHT);
                            cs.connect(professorOakAdd.getId(), ConstraintSet.BOTTOM, linearLayout2.getId(), ConstraintSet.BOTTOM);
                            cs.applyTo(constraintLayout);

                        }
                    });
                }
            }
        });
    }

    public class ashThread extends Thread {
        public void run() {
            while (scoreGreaterThanZero) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                int beingAdded = (refundClicker + 1) * ashScore;
                if (!refunded)
                    score.getAndAdd(1);
                else
                    score.getAndAdd(beingAdded);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        scoreTitle.setText("Pokemon Caught: " + score.get());
                    }
                });

                checkForAsh();
                checkForProfessor();
            }

        }
    }

    public class professorOakThread extends Thread {
        public void run() {
            while (scoreGreaterThanZero) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                int beingAdded = (refundClicker + 1) * proffessorScore;
                if (!refunded)
                    score.getAndAdd(2);
                else
                    score.getAndAdd(beingAdded);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        scoreTitle.setText("Pokemon Caught: " + score.get());
                    }
                });

                checkForAsh();
                checkForProfessor();
            }

        }
    }
}
